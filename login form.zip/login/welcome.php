<?php
include('connect.php');





?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>welcome</title>
    <style>
        h1{
            color: green;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }
    </style>

</head>
<body>
    <center><h1>WELCOME TO LOGIN PAGE...</h1>
    <h2>Please click on login for login page!..</h2>

    <h1><a href="login.php">login</a></h1></center>
</body>
</html>




