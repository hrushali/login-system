<?php
session_start();
include("connect.php");

if ($_SERVER['REQUEST_METHOD']== "POST" ){
    $email = $_POST['email'];
    $password = $_POST['pass'];

    if (!empty($email) && !empty($password) && !is_numeric($email))  
    {
        
        $query = "SELECT * FROM login WHERE email = '$email'";
         $result = mysqli_query($conn, $query);
         if($result && mysqli_num_rows($result)>0){
            $query = "SELECT * FROM login WHERE pass = '$password'";
            $result1 = mysqli_query($conn, $query);
            if($result1 && mysqli_num_rows($result1)>0){
                header("location: welcome.php");
            }
            else{
                echo "<script type='text/javascript'>alert('not result found password')</script>";
            }

         }
         else{
            echo "<script type='text/javascript'>alert('not result found email')</script>";
         }
        
        } else {
            echo "<script type='text/javascript'>alert('Incorrect empty')</script>";
        }
    } else {
        echo "";
    }

?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <style>
        .navbar h1 {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
          color: blue;
         border-radius: 10px;
        }
        h3{
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }
        h2{
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }
        .container{
            background: white;
            position: absolute;
            display:block;
            color: black;
            padding: 30px 60px ;
            margin-left: 550px; 
            border: 2px solid yellow;
            border-radius: 5px;
            
        }
        input{
           
            border:3px solid brown;
            border-radius: 5px;
        }
        .box{
            padding: 8px 70px;
        }
        button{
          margin-left: 100px; 
          color: white;
          background: brown;
          padding: 10px 20px;
          border-radius: 5px;
          font-size: larger;
        }
        label{
            font-size: larger;
            border-radius: 5px solid black;
            font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif    ;
            
                
        }
         
    </style>
</head>
<body style="background-color: orange;">
    <nav class="navbar">
       <center><h1>LOGIN</h1>
      
       
       </center> 
      
    </nav>
<div class="container">
    
    <form action="" method="post">
        <label for="email">Email:</label><br> 
        <input type="email" id="email" class="box" name="email" placeholder="enter the username..."><br><br>
        
        <label for="password">Password:</label><br>
        <input type="password" id="pass" class="box" name="pass" placeholder="enter the password..."><br><br>
       
        <button type="submit" name="submit" value="login" >Login</button><br><br>
        <u class="line"><a href="signup.php">Already have not account Click Here for signup.!</a></u>
    </form><br>
   
</div>
</body>
</html>
